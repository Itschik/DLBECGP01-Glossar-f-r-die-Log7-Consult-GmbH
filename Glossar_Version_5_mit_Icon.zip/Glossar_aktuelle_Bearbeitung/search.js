function searchGlossar() {
  const input = document.getElementById("searchInput").value.trim().toLowerCase();
  const pages = {
    "kunde": "Begriffe/kunde.html",
    "adresse": "Begriffe/adresse.html",
    "update": "Begriffe/update.html",
    "daten": "Begriffe/daten.html",
    "anfrage": "Begriffe/anfrage.html"
  };

  if (input in pages) {
    window.location.href = pages[input];
  } else {
    document.getElementById("searchResult").textContent = "Begriff nicht gefunden.";
  }
}

//_________________________________________________________________________________________________
// Zusätzlicher Teil der Empfehlung für die Umsetzung:

// Favoriten aus dem localStorage holen und anzeigen
function zeigeFavoritenAufStartseite() {
  const favoritenListe = document.getElementById("favoriten-liste");
  // Liste leeren
  favoritenListe.innerHTML = ""; 
  const favoriten = JSON.parse(localStorage.getItem("favoriten")) || [];

  // Alphabetisch sortieren (Groß-/Kleinschreibung ignorieren)
  favoriten.sort((a, b) => a.localeCompare(b, 'de', { sensitivity: 'base' }));

  favoriten.forEach(fav => {
    const li = document.createElement("li");
    const link = document.createElement("a");
    link.href = `./Begriffe/${fav.toLowerCase()}.html`; 
    link.textContent = fav;
    li.appendChild(link);
    favoritenListe.appendChild(li);
  });
}

// Beim Laden der Seite Favoriten anzeigen
zeigeFavoritenAufStartseite();
