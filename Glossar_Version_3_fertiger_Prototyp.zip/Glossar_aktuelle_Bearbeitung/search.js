function searchGlossar() {
  const input = document.getElementById("searchInput").value.trim().toLowerCase();
  const pages = {
    "kunde": "Begriffe/kunde.html",
    "adresse": "Begriffe/adresse.html",
    "update": "Begriffe/update.html",
    "daten": "Begriffe/daten.html",
    "anfrage": "Begriffe/anfrage.html"
  };

  if (input in pages) {
    window.location.href = pages[input];
  } else {
    document.getElementById("searchResult").textContent = "Begriff nicht gefunden.";
  }
}
